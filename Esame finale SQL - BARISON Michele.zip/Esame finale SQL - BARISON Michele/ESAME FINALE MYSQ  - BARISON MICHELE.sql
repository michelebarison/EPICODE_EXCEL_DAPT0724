
-- Task 2 Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).


-- Creazione del database
CREATE DATABASE ToysGroup;
USE ToysGroup;

-- Creazione della tabella Category
CREATE TABLE Category (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL
);

-- Creazione della tabella Region
CREATE TABLE Region (
    RegionID INT AUTO_INCREMENT PRIMARY KEY,
    RegionName VARCHAR(100) NOT NULL
);


-- Creazione della tabella Product
CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    CategoryID INT NOT NULL,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);


-- Creazione della tabella Country
CREATE TABLE Country (
    CountryID INT AUTO_INCREMENT PRIMARY KEY,
    CountryName VARCHAR(100) NOT NULL,
    RegionID INT NOT NULL,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);



-- Creazione della tabella Sales
CREATE TABLE Sales (
    SalesID INT AUTO_INCREMENT PRIMARY KEY,
    SalesAmount DECIMAL(10, 2) NOT NULL,
    ProductID INT NOT NULL,
    CountryID INT NOT NULL,
    SaleDate DATE NOT NULL,
    Quantity INT NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (CountryID) REFERENCES Country(CountryID)
);

-- Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) 



-- Popolamento tabella Category
INSERT INTO Category (CategoryName) VALUES
('Bikes'),
('Clothing'),
('Helmets'),
('Toys'),
('Electronics'),
('Outdoor Equipment'),
('Books'),
('Sports'),
('Accessories'),
('Board Games');


-- Popolamento tabella Region

INSERT INTO Region (RegionName) VALUES
('NorthAmerica'),
('SouthAmerica'),
('WestEurope'),
('EastEurope'),
('Asia'),
('Africa'),
('Australia'),
('MiddleEast'),
('CentralAmerica'),
('SouthEastAsia');

-- Popolamento tabella Product

INSERT INTO Product (ProductName, CategoryID) VALUES
('Bike-100', 1),      -- Categoria Bikes
('Bike-200', 1),
('Helmet Pro', 3),    -- Categoria Helmets
('Helmet Basic', 3),
('Rain Jacket', 2),   -- Categoria Clothing
('Soccer Ball', 8),   -- Categoria Sports
('Tent 4-Person', 6), -- Categoria Outdoor Equipment
('Smartwatch', 5),    -- Categoria Electronics
('Chess Board', 10),  -- Categoria Board Games
('Travel Bag', 9);    -- Categoria Accessories

-- Popolamento tabella Country

INSERT INTO Country (CountryName, RegionID) VALUES
('United States', 1),     -- Regione NorthAmerica
('Canada', 1),
('Brazil', 2),            -- Regione SouthAmerica
('Argentina', 2),
('France', 3),            -- Regione WestEurope
('Germany', 3),
('Russia', 4),            -- Regione EastEurope
('China', 5),             -- Regione Asia
('Australia', 7),         -- Regione Australia
('India', 5);             -- Regione Asia


-- Popolamento tabella Sales

INSERT INTO Sales (SalesAmount, ProductID, CountryID, SaleDate, Quantity) VALUES
(500.00, 1, 1, '2021-03-15', 5),  -- Bike-100, United States
(750.00, 2, 2, '2022-05-10', 7),  -- Bike-200, Canada
(120.00, 3, 3, '2023-08-20', 3),  -- Helmet Pro, Brazil
(100.00, 4, 4, '2020-12-01', 2),  -- Helmet Basic, Argentina
(50.00, 5, 5, '2024-01-17', 10),  -- Rain Jacket, France
(80.00, 6, 6, '2019-06-14', 20),  -- Soccer Ball, Germany
(300.00, 7, 7, '2025-04-22', 1),  -- Tent 4-Person, Russia
(200.00, 8, 8, '2021-11-05', 2),  -- Smartwatch, China
(40.00, 9, 9, '2023-02-28', 4),   -- Chess Board, Australia
(100.00, 10, 10, '2020-09-09', 6); -- Travel Bag, India

SELECT * FROM Category;
SELECT * FROM Region;
SELECT * FROM Product;
SELECT * FROM Country;
SELECT * FROM Sales;

-- Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:

/*1	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare 
l’univocità dei valori di ciascuna PK (una query per tabella implementata)*/

-- Interrogo tabella Category
SELECT CategoryID, COUNT(*) AS Occurrences
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

-- Interrogo tabella Region
SELECT RegionID, COUNT(*) AS Occurrences
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- Interrogo tabella Product
SELECT ProductID, COUNT(*) AS Occurrences
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- Interrogo tabella Country
SELECT CountryID, COUNT(*) AS Occurrences
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

-- Interrogo tabella Sales
SELECT SalesID, COUNT(*) AS Occurrences
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

/*2	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, 
il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/


SELECT 
    s.SalesID AS CodiceDocumento,          -- Codice documento
    s.SaleDate AS DataVendita,            -- Data della vendita
    p.ProductName AS NomeProdotto,        -- Nome del prodotto
    c.CategoryName AS CategoriaProdotto,  -- Categoria del prodotto
    co.CountryName AS NomeStato,          -- Nome del paese
    r.RegionName AS NomeRegione,          -- Nome della regione di vendita
    CASE 
        WHEN DATEDIFF(CURRENT_DATE, s.SaleDate) > 180 THEN TRUE
        ELSE FALSE
    END AS PiùDi180Giorni                -- Campo booleano
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN 
    Category c ON p.CategoryID = c.CategoryID
JOIN 
    Country co ON s.CountryID = co.CountryID
JOIN 
    Region r ON co.RegionID = r.RegionID;
    
    
    
/*3 Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito.
 (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire solo il codice prodotto e il totale venduto*/
    
    
SELECT 
    s.ProductID,                                  -- Codice prodotto
    SUM(s.Quantity) AS TotaleVenduto             -- Totale venduto
FROM 
    Sales s
WHERE 
    YEAR(s.SaleDate) = (                          -- Considera solo l'ultimo anno censito
        SELECT MAX(YEAR(SaleDate)) 
        FROM Sales
    )
GROUP BY 
    s.ProductID
HAVING 
    SUM(s.Quantity) > (                           -- Condizione: quantità totale superiore alla media
        SELECT AVG(totale_annuale.QuantitàTotale)
        FROM (
            SELECT SUM(s1.Quantity) AS QuantitàTotale
            FROM Sales s1
            WHERE YEAR(s1.SaleDate) = (           -- Considera solo l'ultimo anno censito
                SELECT MAX(YEAR(SaleDate)) 
                FROM Sales
            )
            GROUP BY s1.ProductID
        ) totale_annuale
    );
-- Non ci sono vendite superiori alla media nell'ultimo anno censito

/*4 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.*/

SELECT 
    p.ProductID,                           -- Codice prodotto
    p.ProductName,                         -- Nome del prodotto
    YEAR(s.SaleDate) AS Anno,              -- Anno della vendita
    SUM(s.SalesAmount) AS FatturatoTotale  -- Fatturato totale
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID -- Collegamento tra vendite e prodotti
GROUP BY 
    p.ProductID, 
    p.ProductName, 
    YEAR(s.SaleDate)
ORDER BY 
    p.ProductID, 
    Anno;
    
/*5 	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/
    

    SELECT 
    co.CountryName AS Stato,               -- Nome dello stato
    YEAR(s.SaleDate) AS Anno,              -- Anno della vendita
    SUM(s.SalesAmount) AS FatturatoTotale  -- Fatturato totale
FROM 
    Sales s
JOIN 
    Country co ON s.CountryID = co.CountryID -- Collegamento tra vendite e stati
GROUP BY 
    co.CountryName, 
    YEAR(s.SaleDate)
ORDER BY 
    Anno ASC,            -- Ordina per anno (crescente)
    FatturatoTotale DESC;-- All'interno dell'anno, ordina per fatturato (decrescente);
    

/*6	Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT 
    c.CategoryName AS Categoria,       -- Nome della categoria
    SUM(s.Quantity) AS QuantitàTotale -- Quantità totale venduta per categoria
FROM 
    Sales s
JOIN 
    Product p ON s.ProductID = p.ProductID
JOIN 
    Category c ON p.CategoryID = c.CategoryID
GROUP BY 
    c.CategoryName
ORDER BY 
    QuantitàTotale DESC
LIMIT 1;

/*7	Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

-- 1 approccio
SELECT 
    p.ProductID, 
    p.ProductName 
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.ProductID = s.ProductID
WHERE 
    s.ProductID IS NULL; -- Nessuna vendita registrata
    
-- 2 approccio    
SELECT 
    p.ProductID, 
    p.ProductName 
FROM 
    Product p
WHERE 
    p.ProductID NOT IN (
        SELECT DISTINCT s.ProductID 
        FROM Sales s
    );
    
    -- NON CI SONO PRODOTTI INVENDUTI NEL DB
    
    /*8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)*/
    
    
    CREATE VIEW DenormalizedProductView AS
SELECT 
    p.ProductID AS CodiceProdotto,       -- Codice del prodotto
    p.ProductName AS NomeProdotto,      -- Nome del prodotto
    c.CategoryName AS NomeCategoria     -- Nome della categoria
FROM 
    Product p
JOIN 
    Category c ON p.CategoryID = c.CategoryID;  -- Collegamento prodotto-categoria
    
    SELECT * FROM DenormalizedProductView;
    
   /*9)	Creare una vista per le informazioni geografiche*/ 
    
    
    CREATE VIEW GeographicInfoView AS
SELECT 
    co.CountryID AS CodicePaese,       -- Codice del paese
    co.CountryName AS NomePaese,       -- Nome del paese
    r.RegionID AS CodiceRegione,       -- Codice della regione
    r.RegionName AS NomeRegione        -- Nome della regione
FROM 
    Country co
JOIN 
    Region r ON co.RegionID = r.RegionID;  -- Collegamento tra paesi e regioni
    
    SELECT * FROM GeographicInfoView;
    